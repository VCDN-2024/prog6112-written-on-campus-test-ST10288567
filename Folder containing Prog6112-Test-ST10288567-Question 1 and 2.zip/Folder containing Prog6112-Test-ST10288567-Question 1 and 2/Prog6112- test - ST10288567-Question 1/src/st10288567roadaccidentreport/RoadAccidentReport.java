/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package st10288567roadaccidentreport;

/**
 * A program to generate a road accident report by capturing accident data from user input
 * and displaying the results, including identifying the city with the highest number of accidents.
 * 
 * @author Darsh Somayi
 */

import java.util.Scanner;

public class RoadAccidentReport {
    // Method to capture and display the accident report
    public void generateReport() {
        // Array of cities
        String[] cities = {"Cape Town", "Johannesburg", "Port Elizabeth"};
        
        // Array of vehicle types
        String[] vehicleTypes = {"Car", "Motorbike"};
        
        // 2D array to store accident data for each city and vehicle type
        // rows = cities, columns = vehicle types
        int[][] accidents = new int[cities.length][vehicleTypes.length];
        
        // Scanner object to take user input
        Scanner scanner = new Scanner(System.in);

        // Loop through each city and input the accident data for both vehicle types
        for (int i = 0; i < cities.length; i++) {
            System.out.println("Enter the number of road accidents for " + cities[i]);
            
            // Loop through the vehicle types and get the number of accidents
            for (int j = 0; j < vehicleTypes.length; j++) {
                System.out.print(vehicleTypes[j] + " accidents: ");
                accidents[i][j] = scanner.nextInt();  // Capture input for the number of accidents
            }
        }
        
        // Displaying the accident report in a formatted manner
        System.out.println("\nRoad Accident Report:");
        System.out.printf("%-15s %-10s %-10s%n", "City", "Cars", "Motorbikes");
        
        // Loop to display the accidents for each city and vehicle type
        for (int i = 0; i < cities.length; i++) {
            System.out.printf("%-15s %-10d %-10d%n", cities[i], accidents[i][0], accidents[i][1]);
        }
        
        // Calculate the total number of accidents per city
        int[] totalAccidentsPerCity = new int[cities.length];
        for (int i = 0; i < cities.length; i++) {
            totalAccidentsPerCity[i] = accidents[i][0] + accidents[i][1];  // Sum of car and motorbike accidents
        }
        
        // Find the city with the highest number of accidents
        int maxAccidents = totalAccidentsPerCity[0];  // Assume the first city has the most accidents initially
        String cityWithMaxAccidents = cities[0];      // Assume the first city is the one with the max accidents
        
        // Loop through the remaining cities to find the actual city with the highest accidents
        for (int i = 1; i < cities.length; i++) {
            if (totalAccidentsPerCity[i] > maxAccidents) {
                maxAccidents = totalAccidentsPerCity[i];  // Update the maximum accident count
                cityWithMaxAccidents = cities[i];         // Update the city with the max accidents
            }
        }

        // Display the city with the highest number of accidents
        System.out.println("\nCity with the highest number of accidents: " + cityWithMaxAccidents);
    }
}



/*
//Reference List

Title: RoadAccidentReport App
//Date: 30 September 2024
//Author: Darsh Somayi
//Sourced: //Farrell, J. 2019. Java Programming. 9th edition. Cengage Learning.
Code version:1
*/