/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package st10288567roadaccidentreport;



/**
 * Main class to run the Road Accident Report application.
 * It creates an instance of the RoadAccidentReport class and invokes its method to generate the report.
 * 
 * @author Darsh Somayi
 */

public class Main {
    public static void main(String[] args) {
        // Create an instance of RoadAccidentReport
        RoadAccidentReport report = new RoadAccidentReport();
        
        // Call the generateReport method to handle user input and display the accident report
        report.generateReport();
    }
}



/*
//Reference List

Title: RoadAccidentReport App
//Date: 30 September 2024
//Author: Darsh Somayi
//Sourced: //Farrell, J. 2019. Java Programming. 9th edition. Cengage Learning.
Code version:1
*/