/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package st10288567roadaccidentreport2;

/**
 *
 * @author Darsh Somayi
 */

public interface iRoadAccidents {
    String getAccidentVehicleType(); // Method to get the vehicle type
    String getCity();                // Method to get the city
    int getAccidentTotal();          // Method to get the number of accidents
}



/*
//Reference List

Title: RoadAccidentReport App
//Date: 30 September 2024
//Author: Darsh Somayi
//Sourced: //Farrell, J. 2019. Java Programming. 9th edition. Cengage Learning.
Code version:1
*/