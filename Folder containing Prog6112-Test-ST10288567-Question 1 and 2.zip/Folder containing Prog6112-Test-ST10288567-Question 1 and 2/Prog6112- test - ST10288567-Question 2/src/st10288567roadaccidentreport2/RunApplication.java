/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package st10288567roadaccidentreport2;

/**
 *
 * @author Darsh Somayi
 */
// The main class to run the application
public class RunApplication {
    
    // The main method - entry point for the Java application
    public static void main(String[] args) {
        // Create an instance of the RoadAccidentsReport class with example data
        RoadAccidentsReport report = new RoadAccidentsReport("Car", "Johannesburg", 45);

        // Call the method to print the accident report on the console
        report.printAccidentsReport();
    }
}



/*
//Reference List

Title: RoadAccidentReport App
//Date: 30 September 2024
//Author: Darsh Somayi
//Sourced: //Farrell, J. 2019. Java Programming. 9th edition. Cengage Learning.
Code version:1
*/