/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package st10288567roadaccidentreport2;

/**
 *
 * @author Darsh Somayi
 */

// Abstract class implementing the iRoadAccidents interface
public abstract class RoadAccidents implements iRoadAccidents {
    // Private variables to store vehicle type, city, and number of accidents
    private String vehicleType;
    private String city;
    private int numAccidents;

    // Constructor to initialize the vehicle type, city, and number of accidents
    public RoadAccidents(String vehicleType, String city, int numAccidents) {
        this.vehicleType = vehicleType;
        this.city = city;
        this.numAccidents = numAccidents;
    }

    // Overridden method to get the type of vehicle involved in accidents
    @Override
    public String getAccidentVehicleType() {
        return vehicleType;
    }

    // Overridden method to get the city where accidents occurred
    @Override
    public String getCity() {
        return city;
    }

    // Overridden method to get the total number of road accidents
    @Override
    public int getAccidentTotal() {
        return numAccidents;
    }
}





/*
//Reference List

Title: RoadAccidentReport App
//Date: 30 September 2024
//Author: Darsh Somayi
//Sourced: //Farrell, J. 2019. Java Programming. 9th edition. Cengage Learning.
Code version:1
*/