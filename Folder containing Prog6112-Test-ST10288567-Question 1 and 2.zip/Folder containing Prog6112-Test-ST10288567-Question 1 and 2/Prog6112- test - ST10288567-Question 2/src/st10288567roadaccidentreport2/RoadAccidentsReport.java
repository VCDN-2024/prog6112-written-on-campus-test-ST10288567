/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package st10288567roadaccidentreport2;

/**
 *
 * @author Darsh Somayi
 */
// Class that extends the RoadAccidents abstract class to report accident details
public class RoadAccidentsReport extends RoadAccidents {
    
    // Constructor to initialize the vehicle type, city, and number of accidents
    public RoadAccidentsReport(String vehicleType, String city, int numAccidents) {
        // Calling the constructor of the superclass (RoadAccidents) to set the values
        super(vehicleType, city, numAccidents);
    }

    // Method to print a formatted report of road accidents
    public void printAccidentsReport() {
        System.out.println("Road Accident Report:");
        System.out.println("Vehicle Type: " + getAccidentVehicleType());  // Display vehicle type
        System.out.println("City: " + getCity());                         // Display city name
        System.out.println("Number of Accidents: " + getAccidentTotal()); // Display number of accidents
    }
}



/*
//Reference List

Title: RoadAccidentReport App
//Date: 30 September 2024
//Author: Darsh Somayi
//Sourced: //Farrell, J. 2019. Java Programming. 9th edition. Cengage Learning.
Code version:1
*/